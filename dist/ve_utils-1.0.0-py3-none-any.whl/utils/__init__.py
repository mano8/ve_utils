# Version of realpython-reader package
__version__ = "1.0.0"